<?php

$utm_medium = $_GET['utm_medium'];
$utm_special = $_GET['utm_special'];
$utm_campaign = $_GET['utm_campaign'];
$utm_source = $_GET['utm_source'];
$email = $_GET['email'];
?>


<!DOCTYPE html>
<html lang="ru">
<head>

<!-- Anti-flicker snippet (recommended)  -->
<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',4000,
{'GTM-TZFD9SP':true});</script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-38087671-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-38087671-1', { 'optimize_id': 'GTM-WJ3GRB5'});
</script>


<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1051247724908752'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1051247724908752&ev=PageView&noscript=1"
/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TZFD9SP');</script>
<!-- End Google Tag Manager -->

	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta charset="UTF-8">
    <title>СИСТЕМА МИЛЛИОНЕРА</title>
    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

    <style>
    .video__frame--content {
        max-width: 100%;
    }
    </style>

</head>
<body>

    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
        (function (d, w, c) { (w[c] = w[c] || []).push(function() {
        try { w.yaCounter39253290 = new Ya.Metrika({ id:39253290, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); }
        catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks");
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/39253290" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
    <!-- /Yandex.Metrika counter -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TZFD9SP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- GA GC -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-38087671-1']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- GC GA -->


    <div class="menu">
        <div class="container">
            <div class="menu-content">
                <div class="logo"><a href="#"><img src="img/logo.png" alt="logo"></a></div>
                <div class="menu-phones">
                    <ul class="menu-list">
                        <li class="menu-item"><img src="img/phone.png" alt="phone" class="menu-pic">+7 (495) 133-82-24 </li>
                        <li class="menu-item"><img src="img/phone.png" alt="phone" class="menu-pic">+38 (096) 916-13-88</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section class="checkList">
        <div class="container">
            <div class="checkList-content text-center">
                <p><span class="bold">Внимание! Без этой информации даже ежедневное 60-минутное <br>прослушивание аффирмаций может не принести вам реальный результат!</span></p>
                <p>Пока система отправляет вам записи (обычно это занимает около 5 минут),
                	<span class="checkList-text">посмотрите ВНИМАТЕЛЬНО специальную видео-презентацию Ивана Зимбицкого «СИСТЕМА МИЛЛИОНЕРА»…</span></p>
            </div>
            <div class="checkList-figure d-flex justify-content-center align-items-center">
                <img src="img/figure.png" alt="figure">
            </div>
            <div class="checkList-wrap text-center">
                <div class="checkList-video d-inline-block position-relative">
                <iframe class="video__frame--content" src="https://player.vimeo.com/video/364260543?autoplay=1&loop=1&title=0&byline=0&portrait=0" width="890" height="500" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                    <img src="img/arrow_right.png" alt="arrowRight" class="checkList-img1">
                    <img src="img/arrow_left.png" alt="arrowLeft" class="checkList-img2">
                </div>
                <div class="checkList-figure d-flex justify-content-center align-items-center">
                    <img src="img/figure2.png" alt="figure2" class="hidden">
                </div>
            </div>
        </div>
    </section>
    <section class="payment position-relative hidden">
        <div class="container">
            <div class="row">
                <div class="col-xl-10 offset-xl-1 col-12 offset-0">
                    <div class="payment-house position-relative">
                        <div class="payment-content">
                            <p class="payment-text"><span class="black">Оплатите сейчас </span>участие в 3-недельной онлайн-программе, чтобы перепрошить мышление на высокий доход <span class="black">и заберите легендарный 10Х Journal БЕСПЛАТНО!</span> (А в ходе программы получите возможность выиграть MacBook и билеты на события Goldcoach)
                            </p>
                            <div class="set-wrap d-flex justify-content-between align-items-center">
                                <img src="img/set.png" alt="set" class="payment-pic">
                                <span class="payment-plus black">+</span>
                                <img src="img/diary.png" alt="diary" class="payment-pic">
                            </div>
                            <div class="payment-wrap">
                                <button class="payment-btn js-popup-open">Да, Иван! Я хочу <br class="d-md-none d-block">Мышление 10Х>>>></button>
                            </div>
                        </div>
                        <img src="img/orange_arrow_right.png" alt="right" class="payment-img1">
                        <img src="img/orange_arrow_left.png" alt="left" class="payment-img2">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="package hidden">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-12 offset-0">
                    <div class="package-content">
                        <h2 class="h2"><span class="bg-orange">Что Вы Получаетe в Пакете<br> «Мышление 10Х» + 10Х Journal</span></h2>
                        <ul class="package-list">
                            <li class="package-item"><span class="bold">—  4 основных модуля программы</span> (групповые коучинговые созвоны от 90-120 минут каждый)
                                <ul class="package-sublist regular">
                                    <li>«Неудержимый Я»</li>
                                    <li>«Нейрогенезис»</li>
                                    <li>«Ракета» — 27 Принципов Мышления Для Контакта с Реальностью</li>
                                    <li>«Система Успеха, Которая Всегда Работает»</li>
                                </ul>
                            </li>
                            <li class="package-item"><span class="bold">—  1 групповой коучинг-звонок</span> «Ответы на вопросы» (90 минут)</li>
                            <li class="package-item">—  24/7 <span class="bold">доступ к материалам</span> закрытого сайта</li>
                            <li class="package-item">—  <span class="bold">Доступ в группу в мессенджере Telegram</span> с экспертами GoldCoach, Иваном Зимбицким и 678 предпринимателями</li>
                            <li class="package-item"><span class="bold">—  Наставник и сообщество целеустремленных людей</span> (вместе веселее и не так страшно)</li>
                            <li class="package-item">—  Возможность выиграть <span class="bold">MacBook, $300, или $200</span></li>
                        </ul>
                        <h2 class="h2"><span class="bg-orange">3 супер-бонуса ценностью $171 для тех, кто действует сейчас: </span></h2>
                        <ul class="package-list2">
                            <li class="package-item2 d-md-flex d-block align-items-start">
                                <img src="img/bonus_1.png" alt="bonus_1" class="package-pic">
                                <div class="package-wrap">
                                    <p>Бонус 1:</p>
                                    <p class="package-fat">[Мастер-класс]</p>
                                    <p class="package-medium">«План-Ивана: Как За 5 лет сделать 7-ми значную цифру в $»<br>
                                        Как добавить минимум $ 1,000,000 к Вашей чистой стоимости <br>
                                        всего за 5 лет или меньше</p>
                                    <p class="package-orange">(Ценность $37)</p>
                                </div>
                            </li>
                            <li class="package-item2 d-md-flex d-block align-items-start">
                                <img src="img/bonus_2.png" alt="bonus_2" class="package-pic">
                                <div class="package-wrap">
                                    <p>Бонус 2:</p>
                                    <p class="package-fat">Запись телекласса</p>
                                    <p class="package-medium">«Психология Денег» — Найдите и устраните самые опасные <br>
                                        убеждения о деньгах</p>
                                    <p class="package-orange">(Ценность $37)</p>
                                </div>
                            </li>
                            <li class="package-item2 d-md-flex d-block align-items-start">
                                <img src="img/bonus_3.png" alt="bonus_3" class="package-pic">
                                <div class="package-wrap">
                                    <p>Бонус 3:</p>
                                    <p class="package-fat">Система</p>
                                    <p class="package-medium">«Сила Фокуса: 5 шагов к притягиванию ДЕНЕГ с помощью силы
                                        мышления» <br> <br> Как перестать терять возможности из-за расфокуса и начать
                                        притягивать деньги с помощью мышления</p>
                                    <p class="package-orange">(Ценность $97)</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="press hidden">
        <div class="container">
            <div class="row">
                <div class="col-xl-10 offset-xl-1 col-12 offset-0">
                    <div class="press-content">
                        <p class="press-text"><span class="black">Жмите на Кнопку </span>и Получите пакет «Мышление 10Х» + Мгновенный Доступ к Бонусам ценностью $171 всего за $39 <span class="black">и заберите 10x Journal Бесплатно!</span>
                        </p>
                        <div class="set-wrap d-flex justify-content-between align-items-center">
                            <img src="img/set.png" alt="set" class="payment-pic">
                            <span class="press-plus black">+</span>
                            <img src="img/diary.png" alt="diary" class="payment-pic">
                        </div>
                        <div class="press-gold text-center">
                            <p class="press-bold">Ценность комплекта  <span class="press-crossed">$559</span> Цена сейчас $39</p>
                            <button class="press-btn orange-btn js-popup-open">Присоединиться к Программе «Мышление 10Х»</button>
                            <a href="#" class="press-link">Присоединиться к программе “Мышление 10Х”</a>
                            <div class="press-wrap d-flex justify-content-center align-items-center">
                                <img src="img/mastercard.png" alt="mastercard" class="press-bank">
                                <img src="img/visa.png" alt="visa" class="press-bank">
                                <img src="img/sberbank.png" alt="sberbank" class="press-bank">
                                <img src="img/privatbank.png" alt="privatbank" class="press-bank">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="container">
            <div class="footer-wrap d-md-flex d-block justify-content-between align-items-center">
                <ul class="footer-list">
                    <li class="footer-item">GoldCoach.ru 2013-2019</li>
                    <li class="footer-item"><a href="#" class="footer-link">Соглашение на обработку персональных данных</a></li>
                    <li class="footer-item"><a href="#" class="footer-link">Отказ от ответственности</a></li>
                    <li class="footer-item"><a href="#" class="footer-link">О компании GoldCoach</a></li>
                </ul>
                <div class="footer-icons d-flex justify-content-center">
                    <a href="#"><img src="img/icon_fb.png" alt="fb" class="footer-pic"></a>
                    <a href="#"><img src="img/icon_inst.png" alt="inst" class="footer-pic"></a>
                    <a href="#"><img src="img/icon_telegram.png" alt="telegram" class="footer-pic"></a>
                    <a href="#"><img src="img/icon_vk.png" alt="vk" class="footer-pic"></a>
                    <a href="#"><img src="img/icon_youtube.png" alt="youtube" class="footer-pic"></a>
                </div>
            </div>
        </div>
    </footer>
    <div class="popup position-fixed js-popup-close">
        <div class="popup-inner position-absolute">
            <button type="button" class="close js-popup-close" aria-label="Close">
                <span class="js-popup-close" aria-hidden="true">&times;</span>
            </button>
            <p class="popup-inner-text">
                Чтобы забронировать участие в онлайн-программе Мышление 10Х, получить
                мгновенный доступ к бонусам и БЕСПЛАТНО получить 10X Journal - <span class="bold">введите свои данные ниже:</span>
            </p>

            <!-- <form action="" class="form1"> -->
            <script type="text/javascript" src="https://forms.ontraport.com/v2.4/include/formEditor/genjs-v3.php?html=false&uid=p2c9448f902"></script>

            <form class="form1 moonray-form-clearfix" action="https://forms.ontraport.com/v2.4/form_processor.php?" method="post" accept-charset="UTF-8">
                <input type="text" class="input" name="firstname" placeholder="Ваше имя" required>
                <input type="text" class="input" name="email" placeholder="Ваш email" required>
                <input type="text" class="input js-phone-number" name="cell_phone" placeholder="" required>
                <button class="btn-link submit" type="submit">Забронировать участие и получить бонусы</button>

                <label class="policy">
                    <input type="checkbox" name="ch" value="ch" checked class="check checked position-absolute">
                    <small>Я прочел(-ла) и принимаю <a target="_blank" href=" https://goldcoach.ru/agreement/">политику конфиденциальности</a><br>
                        и даю согласие на <a href="https://goldcoach.ru/agreement/" target="_blank">обработку персональных данных</a>.</small>
                </label>

                <input name="afft_" type="hidden" value=""/>
                <input name="aff_" type="hidden" value=""/>
                <input name="sess_" type="hidden" value=""/>
                <input name="ref_" type="hidden" value=""/>
                <input name="own_" type="hidden" value=""/>
                <input name="oprid" type="hidden" value=""/>
                <input name="contact_id" type="hidden" value=""/>
                <input name="referral_page" type="hidden" value=""/>
                <input name="utmspecial_428" type="hidden" value="<?php echo (isset($_GET['utm_special']) ? $_GET['utm_special'] : ''); ?>"/>
                <input name="utmcampaig_224" type="hidden" value="<?php echo (isset($_GET['utm_campaign']) ? $_GET['utm_campaign'] : ''); ?>"/>
                <input name="utmmedium_225" type="hidden" value="<?php echo (isset($_GET['utm_medium']) ? $_GET['utm_medium'] : ''); ?>"/>
                <input name="utmsource_223" type="hidden" value="<?php echo (isset($_GET['utm_source']) ? $_GET['utm_source'] : ''); ?>"/>
                <input name="utm_source" type="hidden" value="<?php echo (isset($_GET['utm_source']) ? $_GET['utm_source'] : ''); ?>" />
                <input name="utm_medium" type="hidden" value="<?php echo (isset($_GET['utm_medium']) ? $_GET['utm_medium'] : ''); ?>" />
                <input name="utm_term" type="hidden" value="<?php echo (isset($_GET['utm_term']) ? $_GET['utm_term'] : ''); ?>" />
                <input name="utm_content" type="hidden" value="<?php echo (isset($_GET['utm_content']) ? $_GET['utm_content'] : ''); ?>" />
                <input name="utm_campaign" type="hidden" value="<?php echo (isset($_GET['utm_campaign']) ? $_GET['utm_campaign'] : ''); ?>" />

                <input name="uid" type="hidden" value="p2c9448f902"/>
                <input name="mopsbbk" type="hidden" value="1D1265B9D2C408D5BA4C7D25:5A14ADD759167E136AF81A59"/>
            </form>
        </div>
    </div>


    <div class="banner">
    <div class="banner-wrap">
        <img src="images/close.png" class="close-banner js-banner-close" alt="">
        <div class="banner-top d-md-flex align-items-center">
            <div class="important mr-2 mr-lg-3">
                Важно!
            </div>
            <div>
                Это предложение действует только <br>
                пока открыт этот баннер!
            </div>
        </div>
        <p class="banner-title mb-2 mb-lg-4">
            Заберите сейчас пакет «Мышление 10Х»
            +ежедневник 10Х Journal с процессом
            выработки мышления миллионера за $27!
        </p>
        <p>
            Цель «Мышления 10Х» — трансформировать мышление предпринимателей постсоветского пространства. Мы не зарабатываем на этой программе.
            <br>
            Поэтому готовы отдать вам  участие в ней и 10Х Journal за $27 при оплате онлайн сейчас (это помогает нам экономить ресурсы отдела продаж и сократить расходы)
        </p>
        <div class="mt-4">
            <div class="banner-buttons">
                <button class="banner-btn js-open-form mr-md-3 mb-2 mb-md-0">
                    ДА, я хочу забрать <br>
                    эту возможность
                </button>
                <button class="banner-btn js-banner-close" style="background-color: #b0b0b0;">
                    НЕТ, я отказываюсь <br>
                    от нее навсегда
                </button>
            </div>
            <script type="text/javascript"
                src="//forms.ontraport.com/v2.4/include/formEditor/genjs-v3.php?html=false&uid=p2c9448f905"></script>

        <form class="form1 moonray-form-clearfix" action="https://forms.ontraport.com/v2.4/form_processor.php?"
              method="post" accept-charset="UTF-8">
                <p class="mb-2">Заполните форму, чтобы
                    воспользоваться возможностью</p>
                <div class="d-md-flex align-items-center justify-content-between">
                    <input type="text" class="input" name="email" placeholder="Ваш email" required>
                    <input type="text" class="input" name="cell_phone" placeholder="Ваш телефон" required>
                    <button class="banner-btn">
                        Воспользоваться возможностью
                    </button>
                <input name="utmspecial_428" type="hidden" value="<?php echo (isset($_GET['utm_special']) ? $_GET['utm_special'] : ''); ?>"/>
                <input name="utmcampaig_224" type="hidden" value="<?php echo (isset($_GET['utm_campaign']) ? $_GET['utm_campaign'] : ''); ?>"/>
                <input name="utmmedium_225" type="hidden" value="<?php echo (isset($_GET['utm_medium']) ? $_GET['utm_medium'] : ''); ?>"/>
                <input name="utmsource_223" type="hidden" value="<?php echo (isset($_GET['utm_source']) ? $_GET['utm_source'] : ''); ?>"/>
                <input name="utm_source" type="hidden" value="<?php echo (isset($_GET['utm_source']) ? $_GET['utm_source'] : ''); ?>" />
                <input name="utm_medium" type="hidden" value="<?php echo (isset($_GET['utm_medium']) ? $_GET['utm_medium'] : ''); ?>" />
                <input name="utm_term" type="hidden" value="<?php echo (isset($_GET['utm_term']) ? $_GET['utm_term'] : ''); ?>" />
                <input name="utm_content" type="hidden" value="<?php echo (isset($_GET['utm_content']) ? $_GET['utm_content'] : ''); ?>" />
                <input name="utm_campaign" type="hidden" value="<?php echo (isset($_GET['utm_campaign']) ? $_GET['utm_campaign'] : ''); ?>" />
                <input name="uid" type="hidden" value="p2c9448f905"/>
                <input name="mopsbbk" type="hidden" value="1D1265B9D2C408D5BA4C7D25:5A14ADD759167E136AF81A59"/>
                </div>
            </form>
        </div>
    </div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/utils.js"></script>
    <script src="js/intlTelInput.js"></script>
    <script src="js/main.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/common.js"></script>
</body>
</html>
